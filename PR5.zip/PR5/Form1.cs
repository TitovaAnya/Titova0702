﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.RowCount = 3;
            dataGridView1.ColumnCount = 4;

            int[,] a = new int[3, 4];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 3; i++)
                for (j = 0; j < 4; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 3; i++)
                for (j = 0; j < 4; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);


            for (int row = 0; row < a.GetLength(0); row++)
            {
                int minValue = Int32.MaxValue; 

                for (int col = 0; col < a.GetLength(1); col++)
                {
                    if (a[row, col] < minValue)

                        minValue = a[row, col]; 


                }

                listBox1.Items.Add(minValue);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.Rows.Clear();

            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 3;

            int[,] a = new int[4, 3];

            Random rnd = new Random();
            for (int i = 0; i < 4; i++) 
            {
                for (int j = 0; j < 3; j++)
                {
                    a[i, j] = rnd.Next(-100, 100); 
                }
            }

            for (int i = 0; i < 4; i++)
            {
                dataGridView1.Rows.Add(); 
                for (int j = 0; j < 3; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = a[i, j]; 
                }
            }

            int maxValue = Int32.MinValue; 
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (a[i, j] > maxValue)
                    {
                        maxValue = a[i, j]; 
                    }
                }
            }

            listBox1.Items.Add($"Наибольший элемент матрицы: {maxValue}");
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.Rows.Clear();

            dataGridView1.RowCount = 15;
            dataGridView1.ColumnCount = 15;

            int[,] f = new int[15, 15];

            Random rnd = new Random();
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    f[i, j] = rnd.Next(-100, 100); 
                }
            }

            for (int i = 0; i < 15; i++)
            {
                dataGridView1.Rows.Add(); 
                for (int j = 0; j < 15; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = f[i, j]; 
                }
            }
            bool found = false;
            double avg = 0;
            int lastFoundIndex = -1;

            for (int i = 0; i < 15; i++)
            {
                if (f[i, 0] == 1) 
                {
                    found = true;
                    lastFoundIndex = i; 
                                      
                    for (int j = 0; j < 15; j++)
                    {
                        avg += f[i, j];
                    }
                    avg /= 15; 
                    break; 
                }
            }
            if (found)
            {
                listBox1.Items.Add($"Строка начинается с 1: Номер строки {lastFoundIndex + 1}, Среднее арифметическое: {avg:F2}");
            }
            else
            {
                listBox1.Items.Add("Строки нет");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.Rows.Clear();
            dataGridView1.RowCount = 7;
            dataGridView1.ColumnCount = 7;

            
            int[,] f = new int[7, 7];

            
            Random rnd = new Random();
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    f[i, j] = rnd.Next(-100, 100); 
                }
            }

            
            for (int i = 0; i < 7; i++)
            {
                dataGridView1.Rows.Add(); 
                for (int j = 0; j < 7; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = f[i, j]; 
                }
            }

            for (int col = 0; col < 7; col++)
            {
                int minInColumn = Int32.MaxValue; 
                for (int row = 0; row < 7; row++)
                {
                    if (f[row, col] < minInColumn)
                    {
                        minInColumn = f[row, col]; 
                    }
                }
                listBox1.Items.Add($"Столбец {col + 1}: наименьший элемент = {minInColumn}");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.Rows.Clear();
            dataGridView1.RowCount = 12;
            dataGridView1.ColumnCount = 12;

            int[,] a = new int[12, 12];

            Random rnd = new Random();
            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 12; j++)
                {
                    a[i, j] = rnd.Next(-100, 100); 
                }
            }

            for (int i = 0; i < 12; i++)
            {
                dataGridView1.Rows.Add(); 
                for (int j = 0; j < 12; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = a[i, j]; 
                }
            }
            int sum = 0;
            for (int i = 0; i < 12; i++)
            {
                for (int j = i + 1; j < 12; j++) 
                {
                    sum += a[i, j]; 
                }
            }
            listBox1.Items.Add($"Сумма элементов над главной диагональю: {sum}");
        }
    }
}
