﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        public void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias; // Включаем сглаживание

            // Заливка фона поляны (светло-зелёный цвет)
            using (var grassBrush = new SolidBrush(Color.LightGreen))
            {
                g.FillRectangle(grassBrush,0,400,900,50); // Красим фон формы в зеленый цвет
            }

            // Конкретные координаты цветов
            Point[][] positions = new Point[][]
            {
                new Point[] {new Point(50, 300), new Point(350, 300), new Point(650, 300)}, // Первая группа цветов
                new Point[] {new Point(150, 320), new Point(450, 320), new Point(750, 320)}, // Вторая группа цветов
                new Point[] {new Point(250, 350), new Point(550, 350), new Point(850, 350)}  // Третья группа цветов
            };

            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 50, 450, 50, 320);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 150, 450, 150, 340);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 250, 450, 250, 360);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 350, 450, 350, 320);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 450, 450, 450, 340);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 550, 450, 550, 360);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 650, 450, 650, 320);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 750, 450, 750, 340);
            }
            using (var priv = new Pen(Color.Green, 4))
            {
                g.DrawLine(priv, 850, 450, 850, 360);
            }
            using (var poka = new SolidBrush(Color.Yellow))
            {
                g.FillEllipse(poka, 350, 150, 55, 55);
            }
            using (var poka = new SolidBrush(Color.Yellow))
            {
                g.FillEllipse(poka, 380, 170, 85, 85);
            }
            using (var poka = new SolidBrush(Color.Black))
            {
                g.FillEllipse(poka, 365, 165, 10, 10);
            }
            using (var zdr = new SolidBrush(Color.Coral))
            {
                Point[] tra = { new Point(340, 175), new Point(350, 165), new Point(350, 185) };
                e.Graphics.FillPolygon(zdr, tra);
            }

            using (var zdr = new SolidBrush(Color.Orange))
            {
                Point[] tra = { new Point(400, 220), new Point(440, 220), new Point(415, 200) };
                e.Graphics.FillPolygon(zdr, tra);
            }

            using (var priv = new Pen(Color.Black, 4))
            {
                g.DrawLine(priv, 462, 220, 505, 220);
            }
            using (var priv = new Pen(Color.Black, 4))
            {
                g.DrawLine(priv, 462, 230, 505, 230);
            }

            // Три основных цвета лепестков
            Color[] colors = { Color.Red, Color.Blue, Color.Violet };

            // Проходим по каждой точке и рисуем цветок
            for (int groupIndex = 0; groupIndex < positions.Length; groupIndex++)
            {
                Color flowerColor = colors[groupIndex]; // цвет лепестков меняется от группы к группе

                foreach (var position in positions[groupIndex])
                {
                    int x = position.X;
                    int y = position.Y;

                    // Сердцевина цветка (желтая)
                    Rectangle centerRect = new Rectangle(x, y, 20, 20);
                    using (SolidBrush yellowBrush = new SolidBrush(Color.Yellow))
                    {
                        g.FillEllipse(yellowBrush, centerRect); // желтую серединку цветка
                    }

                    // Лепестки цветка
                    double petalRadius = 20;
                    using (SolidBrush flowerBrush = new SolidBrush(flowerColor))
                    {
                        for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 4)
                        {
                            float px = (float)(x + Math.Cos(angle) * petalRadius);
                            float py = (float)(y + Math.Sin(angle) * petalRadius);
                            Rectangle petalRect = new Rectangle((int)px - 15, (int)py - 15, 30, 30);
                            g.FillEllipse(flowerBrush, petalRect); // лепестки цветка
                        }
                    }
                }
            }

        }

        private void DrawFlowersGroup(Graphics g, int x, int y, Color color)
        {
            // Параметры группы цветов
            int count = 10; // Сколько цветов в группе
            int spacing = 50; // Расстояние между цветами

            // Создаём кисть нужного цвета
            using (SolidBrush flowerBrush = new SolidBrush(color))
            {
                for (int i = 0; i < count; i++)
                {
                    // Координаты цветка
                    int currentX = x + i % 5 * spacing; // размещаем в ряд
                    int currentY = y + i / 5 * spacing; // второй ряд под первым

                    // Центральная часть цветка
                    Rectangle centerRect = new Rectangle(currentX, currentY, 20, 20);
                    g.FillEllipse(flowerBrush, centerRect); // рисуем центр цветка

                    // Лепестки цветка
                    double petalRadius = 20;
                    for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 4)
                    {
                        float px = (float)(currentX + Math.Cos(angle) * petalRadius);
                        float py = (float)(currentY + Math.Sin(angle) * petalRadius);
                        Rectangle petalRect = new Rectangle((int)px - 15, (int)py - 15, 30, 30);
                        g.FillEllipse(flowerBrush, petalRect); // рисуем лепестки
                    }
                }
            }
        }
    }
}
 


