﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PR3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Vip_Click(object sender, EventArgs e)
        {
            var selectedItems = listBox1.SelectedItems.Cast<string>();
            int zeroCount = 0;
            int oneCount = 0;

            foreach (var item in selectedItems)
            {
                foreach (char digit in item)
                {
                    if (digit == '0')
                        zeroCount++;
                    else if (digit == '1')
                        oneCount++;
                }
            }
            label1.Text = $"Нулей: {zeroCount}, Единиц: {oneCount}";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputString = listBox1.Text.Trim();
            string[] words = inputString.Split(new char[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            int wordCount = words.Length;
            label1.Text = $"Количество слов: {wordCount}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string inputString = listBox1.Text;
            int punctuationCount = 0;
            foreach (char symbol in inputString)
            {
                if (Char.IsPunctuation(symbol))
                {
                    punctuationCount++; 
                }
            }
            label1.Text = $"Знаков препинания: {punctuationCount}";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string inputString = listBox1.Text;
            List<char> digits = new List<char>();
            foreach (char symbol in inputString)
            {
                if (Char.IsDigit(symbol)) 
                {
                    digits.Add(symbol);
                }
            }
            string resultDigits = string.Join("", digits);
            label1.Text = $"Цифры: {resultDigits}";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string inputString = listBox1.Text.Trim();
            string[] numbersStr = inputString.Split(' ');
            int evenNumbersCount = 0;
            foreach (string numStr in numbersStr)
            {
                if (int.TryParse(numStr, out int number))
                {
                    if (number % 2 == 0)
                    {
                        evenNumbersCount++;
                    }
                }
            }
            label1.Text = $"Четных чисел: {evenNumbersCount}";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string inputString = listBox1.Text;
            int lowercaseRussianLettersCount = 0;
            foreach (char symbol in inputString)
            {
                if (symbol >= 'а' && symbol <= 'я')
                {
                    lowercaseRussianLettersCount++; 
                }
            }
            label1.Text = $"Строчных русских букв: {lowercaseRussianLettersCount}";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string inputString = listBox1.Text;
            var filteredLetters = inputString.Where(c => c >= 'а' && c <= 'я');
            string result = new string(filteredLetters.ToArray());
            label1.Text = $"Строчные русские буквы: {result}";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1 && listBox1.Items.Count > 0)
            {
                string inputText = listBox1.Items[selectedIndex].ToString();
                string[] words = inputText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < words.Length; i++)
                {
                    if (words[i].Length > 0)
                    {
                        char firstChar = Char.ToUpper(words[i][0]);
                        string restOfWord = words[i].Substring(1);
                        words[i] = firstChar + restOfWord;
                    }
                }
                string result = String.Join(" ", words);
                label1.Text = result;
            }
            else
            {
                label1.Text = "Ничего не выделено!";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1 && listBox1.Items.Count > 0)
            {
                string inputText = listBox1.Items[selectedIndex].ToString();
                string[] words = inputText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < words.Length; i++)
                {
                    if (words[i].Length > 1)
                    {
                        words[i] = words[i].Substring(1);
                    }
                    else
                    {
                        words[i] = "";
                    }
                }
                string result = String.Join(" ", words);
                label1.Text = result.Trim();
            }
            else
            {
                label1.Text = "Ничего не выделено!";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1 && listBox1.Items.Count > 0)
            {
                string inputText = listBox1.Items[selectedIndex].ToString();
                bool success = true;
                int indexI = 0, indexJ = 0;
                try
                {
                    indexI = Convert.ToInt32(textBox1.Text);
                    indexJ = Convert.ToInt32(textBox2.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка преобразования значений: {ex.Message}");
                    success = false;
                }
                if (!success || indexI >= inputText.Length || indexJ >= inputText.Length ||
                   indexI < 0 || indexJ < 0)
                {
                    label1.Text = "Некорректные индексы!";
                    return;
                }
                char[] chars = inputText.ToCharArray();
                char temp = chars[indexI];
                chars[indexI] = chars[indexJ];
                chars[indexJ] = temp;
                string outputText = new string(chars);
                label1.Text = outputText;
            }
            else
            {
                label1.Text = "Ничего не выделено!";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string inputText = listBox1.Text;
            string[] words = inputText.Split(' ');
            string[] modifiedWords = new string[words.Length];

            for (int i = 0; i < words.Length; i++)
            {
                string word = words[i];
                if (word.Length > 1)
                {
                    char firstLetter = word[word.Length - 1];
                    char lastLetter = word[0];
                    modifiedWords[i] = firstLetter + word.Substring(1, word.Length - 2) + lastLetter;
                }
                else
                {
                    modifiedWords[i] = word;
                }
            }
            string result = string.Join(" ", modifiedWords);
            label1.Text = result;
        }
        private void button12_Click(object sender, EventArgs e)
        {
            string inputText = listBox1.Text;
            char[] chars = inputText.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                if ((chars[i] >= 'A' && chars[i] <= 'Z') || (chars[i] >= 'a' && chars[i] <= 'z'))
                {
                    chars[i] = '+';
                }
            }
            string result = new string(chars);
            label1.Text = result;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            string inputText = listBox1.Text;
            char[] chars = inputText.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                if (chars[i] == 'А')
                {
                    chars[i] = '*';
                }
            }
            string result = new string(chars);
            label1.Text = result;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            string inputText = listBox1.Text;
            string cleanedText = CleanAndNormalize(inputText);
            bool isPalindrome = CheckIfPalindrome(cleanedText);
            label1.Text = $"Является палиндромом: {(isPalindrome ? "Да" : "Нет")}";
        }
        private string CleanAndNormalize(string text)
        {
            var normalized = new System.Text.RegularExpressions.Regex("[^а-яё]+", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);
            return normalized.Replace(text.ToLower(), "");
        }
        private bool CheckIfPalindrome(string text)
        {
            int left = 0;
            int right = text.Length - 1;
            while (left < right)
            {
                if (text[left++] != text[right--])
                {
                    return false;
                }
            }
            return true;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            string inputText = listBox1.Text;
            string[] words = inputText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string[] lengths = new string[words.Length];

            for (int i = 0; i < words.Length; i++)
            {
                lengths[i] = words[i].Length.ToString();
            }
            string result = string.Join(" ", lengths);
            label1.Text = result;
        }
    }
}
