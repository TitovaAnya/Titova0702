﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form3 : Form
    {
        private int carX = 50;          // Начальная позиция автомобиля по оси X
        private int wheelRotationAngle = 0; // Угол вращения колёс
        private bool movingRight = true; // Направление движения

        public Form3()
        {
            InitializeComponent();
            DoubleBuffered = true;       // Антимерцание при перерисовке
            timer1.Interval = 1;      // Частота кадров (обновление каждые 100 миллисекунд)
            timer1.Tick += Timer1_Tick;  // Обработка события таймера
            timer1.Start();              // Старт таймера
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            // Движение автомобиля вправо-влево
            if (movingRight)
            {
                carX++; // Передвигаемся направо
                if (carX > ClientSize.Width - 100) // Ограничение передвижения вправо
                {
                    movingRight = false;
                }
            }
            else
            {
                carX--; // Передвигаемся налево
                if (carX < 0) // Ограничение передвижения влево
                {
                    movingRight = true;
                }
            }

            // Обновляем угол вращения колёс
            wheelRotationAngle += 10; // Увеличение угла вращения на 10 градусов за кадр

            Invalidate(); // Перерисовка формы
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.LightBlue); // Голубой фон

            // Рисуем корпус автомобиля
            Rectangle bodyRect = new Rectangle(carX, 150, 100, 40); // прямоугольник кузова
            g.FillRectangle(Brushes.Blue, bodyRect); // зелёный кузов

            // Рисуем заднее колесо
            Rectangle backWheelRect = new Rectangle(carX + 20, 180, 20, 20); // задний обод
            g.FillEllipse(Brushes.Black, backWheelRect); // чёрное заднее колесо
            Matrix rotationMatrixBack = new Matrix();
            rotationMatrixBack.RotateAt(wheelRotationAngle, new PointF(backWheelRect.Left + backWheelRect.Width / 2, backWheelRect.Top + backWheelRect.Height / 2)); // матрица вращения заднего колеса
            g.Transform = rotationMatrixBack;
            g.DrawEllipse(Pens.White, backWheelRect); // белая разметка спиц на заднем колесе
            g.ResetTransform(); // сброс преобразований

            // Рисуем переднее колесо
            Rectangle frontWheelRect = new Rectangle(carX + 60, 180, 20, 20); // передний обод
            g.FillEllipse(Brushes.Black, frontWheelRect); // чёрное переднее колесо
            Matrix rotationMatrixFront = new Matrix();
            rotationMatrixFront.RotateAt(wheelRotationAngle, new PointF(frontWheelRect.Left + frontWheelRect.Width / 2, frontWheelRect.Top + frontWheelRect.Height / 2)); // матрица вращения переднего колеса
            g.Transform = rotationMatrixFront;
            g.DrawEllipse(Pens.White, frontWheelRect); // белая разметка спиц на переднем колесе
            g.ResetTransform(); // сброс преобразований
        }
    
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.ShowDialog();
        }
    }
}
