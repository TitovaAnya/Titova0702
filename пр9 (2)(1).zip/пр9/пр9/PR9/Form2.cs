﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form2 : Form
    {
        private List<Point> snowflakes = new List<Point>(); // Список снежинок
        private Random rand = new Random(); // Генератор случайных чисел


        public Form2()
        {
            InitializeComponent();
            DoubleBuffered = true; 
            timer1.Interval = 100; 
            timer1.Tick += Timer1_Tick; 
            timer1.Start(); 
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            
            for (int i = 0; i < snowflakes.Count; i++)
            {
                snowflakes[i] = new Point(snowflakes[i].X, snowflakes[i].Y + 5); 
            }

            
            snowflakes.RemoveAll(flake => flake.Y > ClientSize.Height);

            if (rand.NextDouble() < 0.5) 
            {
                int xPosition = rand.Next(0, ClientSize.Width); 
                snowflakes.Add(new Point(xPosition, -10));
            }

            Invalidate(); 
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.Blue);

            // Рисуем каждую снежинку в виде белого кружочка
            foreach (var flake in snowflakes)
            {
                g.FillEllipse(new SolidBrush(Color.White), flake.X, flake.Y, 10, 10); // Маленькие белые кружочки
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form= new Form3();
            form.ShowDialog();
        }
    }
}
