﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form4 : Form
    {
        private Point starPosition = new Point(200, 200); // начальное положение звезды
        private Random random = new Random();
        private Timer timer;

        public Form4()
        {
            InitializeComponent();

            this.DoubleBuffered = true; // оптимизация перерисовки формы

            // Настройка таймера
            timer = new Timer { Interval = 50 };
            timer.Tick += OnTimerTick;
            timer.Start(); // запускаем таймер сразу же
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawStar(e.Graphics, starPosition.X, starPosition.Y);
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            MoveStarRandomly();
            Invalidate(); // запрашиваем обновление формы
        }

        private void MoveStarRandomly()
        {
            int dx = random.Next(-5, 6); // случайное смещение X (-5..+5)
            int dy = random.Next(-5, 6); // случайное смещение Y (-5..+5)

            starPosition.X += dx;
            starPosition.Y += dy;

            // Ограничение границ формы
            if (starPosition.X < 0 || starPosition.X > ClientSize.Width)
                starPosition.X -= dx * 2;

            if (starPosition.Y < 0 || starPosition.Y > ClientSize.Height)
                starPosition.Y -= dy * 2;
        }

        private void DrawStar(Graphics g, float x, float y)
        {
            using (Brush brush = new SolidBrush(Color.Yellow)) // Жёлтый цвет заливки
            {
                var points = GetStarPoints(x, y);
                g.FillPolygon(brush, points.ToArray()); // Заливка полигона
            }
        }

       
        private List<PointF> GetStarPoints(float centerX, float centerY)
        {
            const double outerRadius = 50; // внешний радиус звезды
            const double innerRadius = 25; // внутренний радиус звезды
            const int numPoints = 5;       // количество вершин звезды
            var angleStep = Math.PI / numPoints;   // угол между вершинами

            var points = new List<PointF>();

            for (var i = 0; i < numPoints * 2; ++i)
            {
                bool isOuterPoint = i % 2 == 0;
                double radius = isOuterPoint ? outerRadius : innerRadius;
                double theta = i * angleStep + Math.PI / 2;

                float pointX = (float)(centerX + radius * Math.Cos(theta));
                float pointY = (float)(centerY + radius * Math.Sin(theta));

                points.Add(new PointF(pointX, pointY));
            }

            return points;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.ShowDialog();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
