﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form1 : Form
    {
        private float scaleFactor = 1.0f; // Текущий масштаб сердца
        private bool isScalingUp = true;  // Показатель, растет сердце или уменьшается
        private Timer animationTimer;

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            animationTimer = new Timer { Interval = 1000 };
            animationTimer.Tick += timer1_Tick_1;
            animationTimer.Start();
        }


        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Применяем матрицу трансформации для изменения размера и положения
            Matrix transformMatrix = new Matrix();
            transformMatrix.Scale(scaleFactor, scaleFactor); // Масштабируем форму
            transformMatrix.Translate((Width / 2) * (1 - scaleFactor), (Height / 2) * (1 - scaleFactor)); // Центрируем масштабирование
            g.Transform = transformMatrix;

            // Рисуем элементы сердца
            g.FillEllipse(new SolidBrush(Color.Red), 300, 100, 100, 100);
            g.FillEllipse(new SolidBrush(Color.Red), 375, 100, 100, 100);
            Point heartPoint1 = new Point(306, 175);
            Point heartPoint2 = new Point(469, 175);
            Point heartPoint3 = new Point(388, 255);
            Point[] heartPoints = { heartPoint1, heartPoint2, heartPoint3 };
            g.FillPolygon(new SolidBrush(Color.Red), heartPoints);
        }






        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.ShowDialog();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        
        {
            // Эффект пульсации
            if (isScalingUp)
            {
                scaleFactor += 0.05f;
                if (scaleFactor >= 1.3f)
                    isScalingUp = false;
            }
            else
            {
                scaleFactor -= 0.05f;
                if (scaleFactor <= 1f)
                    isScalingUp = true;
            }

            Invalidate(); // Инвалидация сцены
        }


        
        
    }
}

