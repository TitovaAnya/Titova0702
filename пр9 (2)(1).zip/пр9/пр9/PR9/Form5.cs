﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form5 : Form
    {
        private readonly Button _startButton; // кнопка запуска
        private readonly Timer _flyTimer;     // таймер для анимации
        private int _yPosition = 400;       // начальная позиция ракеты по оси Y
        private bool _isLaunched = false;    // состояние ракеты (взлетает или нет)

        public Form5()
        {
            InitializeComponent();
            // Задание характеристик формы
            
            StartPosition = FormStartPosition.CenterScreen;
            

            // Создание кнопки "Старт"
            _startButton = new Button
            {
                Text = "Старт",
                Location = new Point(10, 100),
                Size = new Size(100, 30),
                BackColor = Color.Red,
                FlatStyle = FlatStyle.Flat,
                Font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Bold)
            };
            _startButton.Click += StartButtonClick;
            Controls.Add(_startButton);

            // Таймер для анимации
            _flyTimer = new Timer { Interval = 30 }; // 30 мс (около 30 кадров/секунду)
            _flyTimer.Tick += FlyTimerTick;
        }

        // Обработчик события кнопки "Старт"
        private void StartButtonClick(object sender, EventArgs e)
        {
            if (!_isLaunched)
            {
                _isLaunched = true;
                _startButton.Text = "Стоп";
                _flyTimer.Start(); // запускаем анимацию
            }
            else
            {
                _isLaunched = false;
                _startButton.Text = "Старт";
                _flyTimer.Stop(); // останавливаем анимацию
                _yPosition = 400; // возвращаем ракету в исходное положение
                Refresh(); // принудительно перерисовываем форму
            }
        }

        // Обработчик события таймера
        private void FlyTimerTick(object sender, EventArgs e)
        {
            if (_yPosition > 0)
            {
                _yPosition -= 5; // двигаем ракету вверх на 5 единиц
                Refresh(); // обновляем форму для перерисовки
            }
            else
            {
                _flyTimer.Stop(); // останавливаем анимацию
                _isLaunched = false;
                _startButton.Text = "Старт";
            }
        }

        // Метод для рисования ракеты
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            // применяем сглаживание для красивых линий

            // координаты ракеты (центрирована по горизонтали)
            int x = (Width - 30) / 2;
            int y = _yPosition;

            // Корпус ракеты
            g.FillRectangle(Brushes.Silver, x, y, 30, 100);
            g.DrawRectangle(Pens.Black, x, y, 30, 100);

            // Нос ракеты
            g.FillPolygon(Brushes.White, new Point[] { new Point(x + 15, y - 20), new Point(x, y), new Point(x + 30, y) });

            // Крылья ракеты
            g.FillPolygon(Brushes.Red, new Point[] { new Point(x, y + 100), new Point(x + 15, y + 120), new Point(x + 30, y + 100) });
        }


       
            private void Form5_Load(object sender, EventArgs e)
            {

            }


            private void button1_Click_1(object sender, EventArgs e)
            {
                Form6 form = new Form6();
                form.ShowDialog();
            }
        
    }
}
