﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form6 : Form
    {
        // Листья, которые будут падать
        List<Leaf> leaves = new List<Leaf>();

        // Список деревьев с кронами
        List<TreeWithCrown> trees = new List<TreeWithCrown>();

        // Генератор случайных чисел
        static readonly Random random = new Random();

        // Таймер для управления анимацией

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        public Form6()
        {
            InitializeComponent();
            DoubleBuffered = true; // Устраняем мерцание

            // Настройка таймера
            timer1 = new System.Windows.Forms.Timer();
            timer1.Interval = 50; // Интервал обновления в миллисекундах
            timer1.Tick += Timer1_Tick; // Обработчик события таймера
            timer1.Start(); // Запускаем таймер

            // Добавляем деревья и листья
            AddTreesAndLeaves();
        }

        // Добавляем деревья и листья
        private void AddTreesAndLeaves()
        {
            // Создаем два дерева с кроной
            TreeWithCrown tree1 = new TreeWithCrown(
                new Point(100, 50),
                new Point(100, 150),
                Color.Brown,
                random.Next(80, 120)); // Размер кроны
            TreeWithCrown tree2 = new TreeWithCrown(
                new Point(300, 50),
                new Point(300, 150),
                Color.Brown,
                random.Next(80, 120)); // Размер кроны
            trees.Add(tree1);
            trees.Add(tree2);

            // Создаем листья, падающие с ветвей
            for (int i = 0; i < 10; i++) // Добавляем 10 листьев
            {
                Leaf leaf = new Leaf(random.Next(50, 350), 50, random.Next(10, 20), random.Next(5, 15), Color.FromArgb(random.Next(0, 255), random.Next(0, 255), 0));
                leaves.Add(leaf);
            }
        }

        // Класс листа
        class Leaf
        {
            public int X { get; set; }
            public int Y { get; set; }
            public int Size { get; set; }
            public int Speed { get; set; }
            public Color Color { get; set; }
            public double Direction { get; set; } // Угол наклона

            public Leaf(int x, int y, int size, int speed, Color color)
            {
                X = x;
                Y = y;
                Size = size;
                Speed = speed;
                Color = color;
                Direction = 0; // Начальное направление
            }

            // Обновляем позицию листа
            public void Update()
            {
                Y += Speed; // Падает вниз
                X += (int)(Math.Sin(Direction) * Speed); // Боковое смещение
                Direction += 0.1; // Меняем наклон
            }
        }

        // Древо с кроной
        class TreeWithCrown
        {
            public Point Start { get; set; }
            public Point End { get; set; }
            public Color TrunkColor { get; set; }
            public int CrownSize { get; set; }

            public TreeWithCrown(Point start, Point end, Color trunkColor, int crownSize)
            {
                Start = start;
                End = end;
                TrunkColor = trunkColor;
                CrownSize = crownSize;
            }

            // Нарисовать дерево вместе с кроной
            public void Draw(Graphics g)
            {
                // Ствол
                g.DrawLine(new Pen(TrunkColor, 5), Start, End);

                // Координаты центра кроны
                int centerX = End.X;
                int centerY = End.Y - CrownSize / 2;

                // Ширина и высота кроны
                int width = CrownSize + random.Next(-20, 20); // Асимметрия
                int height = CrownSize + random.Next(-20, 20);

                // Создаем кисть с цветом и прозрачностью
                Brush brush = new HatchBrush(HatchStyle.SmallConfetti, Color.Green, Color.Transparent);

                // Круглая крона
                g.FillEllipse(brush, centerX - width / 2, centerY - height / 2, width, height);
            }
        }

        // Обработчик события тика таймера
        private void Timer1_Tick(object sender, EventArgs e)
        {
            // Обновляем положение каждого листа
            foreach (var leaf in leaves.ToArray())
            {
                leaf.Update();

                // Проверяем выход за границу окна
                if (leaf.Y > Height || leaf.X < 0 || leaf.X > Width)
                {
                    leaves.Remove(leaf);
                }
            }

            // Периодически добавляем новые листья
            while (leaves.Count < 10)
            {
                Leaf newLeaf = new Leaf(random.Next(50, 350), 50, random.Next(10, 20), random.Next(5, 15), Color.FromArgb(random.Next(0, 255), random.Next(0, 255), 0));
                leaves.Add(newLeaf);
            }

            Invalidate(); // Перерисовываем форму
        }

        // Метод рисования формы
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.LightBlue); // Светло-голубой фон неба

            // Рисуем деревья с кронами
            foreach (var tree in trees)
            {
                tree.Draw(g);
            }

            // Рисуем листья
            foreach (var leaf in leaves)
            {
                // Овал вместо круга
                g.FillEllipse(new SolidBrush(leaf.Color), leaf.X - leaf.Size / 2, leaf.Y - leaf.Size / 2, leaf.Size * 2, leaf.Size);
            }
        }
    }
}
