﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<int> numbers = new List<int>();
            foreach (var item in Ishodniy.Items)
            {
                if (int.TryParse(item.ToString(), out int value))
                {
                    numbers.Add(value);
                }
            }
            List<int> matchingNumbers = numbers.Where(num => num % 5 == 0 && num % 7 != 0).ToList();
            int count = matchingNumbers.Count;
            int sum = matchingNumbers.Sum();
            Polychenniy.Items.Clear();
            Polychenniy.Items.Add($"Количество элементов: {count}");
            Polychenniy.Items.Add($"Сумма элементов: {sum}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
           List<float> numbers = new List<float>();

            foreach (var item in Ishodniy.Items)
            {
                if (float.TryParse(item.ToString(), out float value))
                {
                    numbers.Add(value);
                }
            }
            List<float> filteredNumbers = numbers.Where(num => num > 3.5f).ToList();
            if (filteredNumbers.Count == 0)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Нет подходящих элементов");
                return;
            }
            float average = filteredNumbers.Average();
            Polychenniy.Items.Clear();
            Polychenniy.Items.Add($"Среднее арифметическое: {average:F2}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            List<int> numbers = new List<int>();
            foreach (var item in Ishodniy.Items)
            {
                if (int.TryParse(item.ToString(), out int value))
                {
                    numbers.Add(value);
                }
            }
            if (numbers.Count < 10)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Недостаточно элементов!");
                return;
            }
            int negativeIndex = -1;
            for (int i = 0; i < numbers.Count; i++)
            {
                if (numbers[i] < 0)
                {
                    negativeIndex = i;
                    break;
                }
            }
            if (negativeIndex == -1)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Отрицательных элементов нет.");
                return;
            }
            long product = 1L;
            for (int i = negativeIndex + 1; i < numbers.Count; i++)
            {
                product *= numbers[i];
            }
            Polychenniy.Items.Clear();
            Polychenniy.Items.Add("Исходный массив:");
            foreach (var number in numbers)
            {
                Polychenniy.Items.Add(number.ToString());
            }
            Polychenniy.Items.Add($"\nПроизведение элементов после первого отрицательного: {product}");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            List<int> numbers = new List<int>();
            foreach (var item in Ishodniy.Items)
            {
                if (int.TryParse(item.ToString(), out int value))
                {
                    numbers.Add(value);
                }
            }
            if (numbers.Count < 14)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Недостаточно элементов!");
                return;
            }
            int negativeIndex = -1;
            for (int i = 0; i < numbers.Count; i++)
            {
                if (numbers[i] < 0)
                {
                    negativeIndex = i;
                    break;
                }
            }
            if (negativeIndex == -1)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Отрицательных элементов нет.");
                return;
            }
            int sum = 0;
            for (int i = 0; i < negativeIndex; i++)
            {
                sum += numbers[i];
            }
            Polychenniy.Items.Clear();
            Polychenniy.Items.Add("Исходный массив:");
            foreach (var number in numbers)
            {
                Polychenniy.Items.Add(number.ToString());
            }
            Polychenniy.Items.Add($"\nСумма элементов до первого отрицательного: {sum}");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            List<int> numbers = new List<int>();
            foreach (var item in Ishodniy.Items)
            {
                if (int.TryParse(item.ToString(), out int value))
                {
                    numbers.Add(value);
                }
            }
            if (numbers.Count < 12)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Недостаточно элементов!");
                return;
            }
            int evenSum = 0;
            foreach (int num in numbers)
            {
                if (num % 2 == 0)
                {
                    evenSum += num;
                }
            }
            Polychenniy.Items.Clear();
            Polychenniy.Items.Add("Исходный массив:");
            foreach (var number in numbers)
            {
                Polychenniy.Items.Add(number.ToString());
            }
            Polychenniy.Items.Add($"\nСумма чётных элементов: {evenSum}");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            List<int> originalNumbers = new List<int>();
            foreach (var item in Ishodniy.Items)
            {
                if (int.TryParse(item.ToString(), out int value))
                {
                    originalNumbers.Add(value);
                }
            }
            if (originalNumbers.Count < 15)
            {
                Polychenniy.Items.Clear();
                Polychenniy.Items.Add("Недостаточно элементов!");
                return;
            }
            List<int> transformedNumbers = new List<int>(originalNumbers.Count);
            foreach (int num in originalNumbers)
            {
                if (num > 0)
                {
                    transformedNumbers.Add(num * num);
                }
                else
                {
                    transformedNumbers.Add(num * 2);
                }
            }
            Polychenniy.Items.Clear();
            Polychenniy.Items.Add("Исходный массив:");
            foreach (var number in originalNumbers)
            {
                Polychenniy.Items.Add(number.ToString());
            }
            Polychenniy.Items.Add("\nПреобразованный массив:");
            foreach (var number in transformedNumbers)
            {
                Polychenniy.Items.Add(number.ToString());
            }
        }
    }
}
